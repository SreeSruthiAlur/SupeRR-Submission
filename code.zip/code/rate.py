import pandas as pd, numpy as np
from sklearn.linear_model import LogisticRegression
b=pd.read_pickle('b3.pkl'); m=pd.read_pickle('m.pkl'); m=m[m.valid]
# --- opposition strength (Bradley-Terry via L2 logistic), standardised within pool (IPL vs international) ---
strength={}
for pool,mp in m.groupby('is_ipl'):
    teams=sorted(set(mp.home_team_id)|set(mp.away_team_id)); ix={t:i for i,t in enumerate(teams)}
    X=np.zeros((len(mp),len(teams)))
    for r,(h,a) in enumerate(zip(mp.home_team_id,mp.away_team_id)): X[r,ix[h]]=1; X[r,ix[a]]=-1
    y=(mp.win_team_id==mp.home_team_id).astype(int)
    lr=LogisticRegression(C=0.7,fit_intercept=True).fit(X,y)
    z=pd.Series(lr.coef_[0],index=teams); z=(z-z.mean())/z.std()
    for t in teams: strength[(pool,t)]=z[t]
b['opp_bat']=[strength.get((i,t),0) for i,t in zip(b.is_ipl,b.batting_team_id)]
b['opp_bowl']=[strength.get((i,t),0) for i,t in zip(b.is_ipl,b.bowling_team_id)]
def adj(v,z,k=0.12):
    w=np.clip(1+k*z,0.7,1.3); return np.where(v>0,v*w,v/w)
THR=b.lev.quantile(.75)
def build(role,thr=THR,k=0.12,use_opp=True):
    if role=='bat':
        d=b[(b.legal==1)&(b.extras_type.isna())].copy()
        d['v']=np.where(d.nonstr_wkt,d.wpoa_alt,d.wpoa); pid='striker_id'; nm='striker_name'; z=d.opp_bowl
    else:
        d=b.copy(); d['v']=-np.where(d.nonbowl_wkt,d.wpoa_alt,d.wpoa); pid='bowler_id'; nm='bowler_name'; z=d.opp_bat
    if use_opp: d['v']=adj(d.v.values,z.values,k)
    d['HP']=d.lev>=thr; d=d.rename(columns={pid:'pid',nm:'pname'})
    return d
if __name__=='__main__':
    for role in ('bat','bowl'):
        d=build(role)
        hp=d[d.HP]
        agg=hp.groupby('pid').agg(n=('v','size'),inn=('match_id',lambda s: 0)).n
        print(role,'players',len(agg),'n_hp quantiles',agg.quantile([.5,.75,.9,.95]).to_dict())
        for t in (60,100,150,200): print(' >=',t,(agg>=t).sum())
