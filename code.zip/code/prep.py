import pandas as pd, numpy as np
b=pd.read_csv('/mnt/user-data/uploads/ball_by_ball.csv',low_memory=False)
m=pd.read_csv('/mnt/project/matches.csv'); c=pd.read_csv('/mnt/project/competitions.csv')
m=m.merge(c[['comp_id','comp_name','match_format','season']],on='comp_id',how='left')
m['is_ipl']=m.comp_name.str.contains('Indian Premier League|IPL',case=False,na=False)
print(m.groupby('is_ipl').size(), m[m.is_ipl].comp_name.unique())
b=b[b.innings.isin([1,2])].copy()
b=b.sort_values(['match_id','innings','innings_ball_num']).reset_index(drop=True)
b['total_runs']=b.runs+b.extras1_runs+b.extras_2_runs
b['legal']=(~b.extras_type.isin(['wide','Overstep','other'])).astype(int)
b['wkt']=(b.is_wicket & (b.dismissal_type!='Retire Out')).astype(int)
g=b.groupby(['match_id','innings'])
b['score_b']=g.total_runs.cumsum()-b.total_runs
b['wk_b']=g.wkt.cumsum()-b.wkt
b['balls_b']=g.legal.cumsum()-b.legal
tot=g.agg(score=('total_runs','sum'),balls=('legal','sum'),wk=('wkt','sum')).reset_index()
print(tot.groupby('innings')[['balls','score','wk']].describe().T)
# valid matches
mm=m.copy()
ok=mm.win_team_id.notna() & mm.revised_target.isna() & mm.first_inn_revised_overs.isna() & mm.second_inn_revised_overs.isna()
i1=tot[tot.innings==1].set_index('match_id'); 
full=i1[(i1.balls>=119)|(i1.wk>=10)].index
ok &= mm.match_id.isin(full)
ok &= mm.match_id.isin(tot[tot.innings==2].match_id)
print('valid matches',ok.sum(),'of',len(mm), 'in b:',mm[ok].match_id.isin(b.match_id).sum())
mm['valid']=ok
b=b[b.match_id.isin(mm[mm.valid].match_id)]
tgt=i1.score+1
b['target']=b.match_id.map(tgt)
b=b.merge(mm[['match_id','comp_id','comp_name','match_format','season','is_ipl','stage','knock_out','win_team_id','match_date']],on='match_id')
b['bat_win']=(b.win_team_id==b.batting_team_id).astype(int)
b.to_pickle('b.pkl'); mm.to_pickle('m.pkl')
print(b.shape, b.match_id.nunique(), b.is_ipl.mean())
