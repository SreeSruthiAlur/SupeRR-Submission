import pandas as pd, numpy as np, itertools, warnings; warnings.filterwarnings('ignore')
from rate import build, b
from score import table, est_k
from scipy.stats import spearmanr
res={}
scen=list(itertools.product([.70,.75,.80],[(0.6,0.15,0.25),(1,0,0),(0.5,0.2,0.3)],[True,False],[0.5,1,2]))
for role in ('bat','bowl'):
    ranks=[]; d0=build(role); k0=est_k(d0)[0]; elig=table(d0,k0).index

    for qt,w,opp,mb in scen:
        d=build(role,thr=b.lev.quantile(qt),use_opp=opp)
        E=table(d,k0*mb,w,elig=elig)
        E['rank']=np.arange(1,len(E)+1); ranks.append(E['rank'].rename(f'{qt}-{w}-{opp}-{mb}'))
    R=pd.concat(ranks,axis=1)
    # only players eligible in every scenario get an aggregated score; others penalised by rank 999 where missing
    names=pd.read_pickle(f'E_{role}.pkl').pname
    cnt=R.notna().sum(1)
    Rf=R.fillna(len(R)+1)  # missing = not eligible => bad
    agg=pd.DataFrame({'mean_rank':Rf.mean(1),'best':R.min(1),'worst':R.max(1),'in_top10':(R<=10).sum(1)/len(scen),'in_top20':(R<=20).sum(1)/len(scen),'n_scen':cnt})
    agg['pname']=names.reindex(agg.index)
    agg=agg.dropna(subset=['pname']).sort_values('mean_rank')
    agg.to_pickle(f'agg_{role}.pkl'); R.to_pickle(f'R_{role}.pkl')
    print(role); print(agg.head(15).round(2).to_string())
