import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from rate import build, b, THR
from score import est_k
fb=pd.read_pickle('final_bat.pkl'); fw=pd.read_pickle('final_bowl.pkl'); rel=pd.read_pickle('reliab.pkl')
top_b=fb.head(10); top_w=fw.head(10)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
# Fig1 leverage by over
fig,ax=plt.subplots(1,2,figsize=(8,2.8))
lv=b.groupby(['innings','overid']).lev.mean().unstack(0)
ax[0].plot(lv.index,lv[1],label='Innings 1 (setting)',color='#4C78A8',lw=2); ax[0].plot(lv.index,lv[2],label='Innings 2 (chasing)',color='#E45756',lw=2)
ax[0].axhline(THR,ls='--',color='grey',lw=1); ax[0].text(1,THR+0.001,'high-pressure threshold',fontsize=7,color='grey')
ax[0].set_xlabel('Over'); ax[0].set_ylabel('Mean leverage'); ax[0].legend(fontsize=7,frameon=False); ax[0].set_title('Pressure builds in the chase death',fontsize=9)
b['HP']=b.lev>=THR; leg=b[b.legal==1]; c2=leg[leg.innings==2]
cl=lambda d:(d.wp_before.sub(.5).abs()<.15).mean()*100
vals={'Close game\n(WP 35-65%), %':(cl(c2[~c2.HP]),cl(c2[c2.HP])),'Mean |win-prob\nswing| per ball, %':(c2[~c2.HP].d_wp.abs().mean()*100,c2[c2.HP].d_wp.abs().mean()*100)}
x=np.arange(2); wd=.35
for i,(k,v) in enumerate(vals.items()): pass
ax[1].bar(x-wd/2,[v[0] for v in vals.values()],wd,label='Normal',color='#9ecae1'); ax[1].bar(x+wd/2,[v[1] for v in vals.values()],wd,label='High pressure',color='#E45756')
ax[1].set_xticks(x); ax[1].set_xticklabels(list(vals.keys()),fontsize=7); ax[1].legend(fontsize=7,frameon=False); ax[1].set_title('Chase: pressure vs ordinary balls',fontsize=9)
plt.tight_layout(); plt.savefig('f1.png',dpi=200); plt.close()
# summary table
def summ(d):
    return [len(d),d.total_runs.mean()*6,(d.total_runs==0).mean()*100,(d.is_four|d.is_six).mean()*100,d.wkt.mean()*100,cl(d),d.d_wp.abs().mean()*100]
rows=[['Group','Balls','Runs/over','Dot %','Boundary %','Wkts/100b','Close %','|ΔWP| %']]
for nm,d in [('All - normal',leg[~leg.HP]),('All - high pressure',leg[leg.HP]),('Chase - normal',c2[~c2.HP]),('Chase - high pressure',c2[c2.HP])]:
    s=summ(d); rows.append([nm,f'{s[0]:,}',f'{s[1]:.2f}',f'{s[2]:.1f}',f'{s[3]:.1f}',f'{s[4]:.2f}',f'{s[5]:.1f}',f'{s[6]:.2f}'])
pv_rows=rows
# Fig bars with CI
def barfig(T,title,fn,col):
    fig,ax=plt.subplots(figsize=(6.2,3.2)); T=T.iloc[::-1]
    ax.barh(T.pname,T.score,color=col,alpha=.85); ax.errorbar(T.score,range(len(T)),xerr=[T.score-T.s_lo,T.s_hi-T.score],fmt='none',ecolor='k',lw=1,capsize=2)
    ax.set_xlabel('Composite pressure score (z-units); bars = 90% bootstrap interval'); ax.set_title(title,fontsize=9); plt.tight_layout(); plt.savefig(fn,dpi=200); plt.close()
barfig(top_b,'Top-10 batters under pressure','f2.png','#E45756'); barfig(top_w,'Top-10 bowlers under pressure','f3.png','#4C78A8')
# Fig shrinkage
d=build('bat'); hp=d[d.HP]; k=est_k(d)[0]
g=hp.groupby('pid').v.agg(['sum','size']); g=g[g['size']>=30]; g['raw']=g['sum']/g['size']*100; g['shr']=g['sum']/(g['size']+k)*100
fig,ax=plt.subplots(figsize=(4.6,3.2)); ax.scatter(g['size'],g.raw,s=8,c='#bbb',label='raw mean'); ax.scatter(g['size'],g.shr,s=8,c='#E45756',label='shrunk')
ax.axhline(0,color='k',lw=.5); ax.set_xlabel('Pressure balls faced'); ax.set_ylabel('WPOA per 100 balls (%)'); ax.legend(frameon=False,fontsize=7); ax.set_title('Shrinkage tames small-sample noise',fontsize=9); plt.tight_layout(); plt.savefig('f4.png',dpi=200); plt.close()
# player evidence
def evid_bat(pid):
    x=hp[hp.pid==pid]; return [f'{x.runs.sum()/len(x)*100:.0f}',f'{(x.is_four|x.is_six).mean()*100:.0f}',f'{x.wkt.mean()*100:.1f}']
db=build('bowl'); hpb=db[db.HP]
def evid_bowl(pid):
    x=hpb[hpb.pid==pid]; w=((x.wkt==1)&(~x.nonbowl_wkt)).sum(); return [f'{x.total_runs.sum()/x.legal.sum()*6:.2f}',f'{w/x.legal.sum()*100:.1f}',f'{((x.total_runs==0)&(x.legal==1)).sum()/x.legal.sum()*100:.0f}']
lg_b=[hp.runs.sum()/len(hp)*100,(hp.is_four|hp.is_six).mean()*100,hp.wkt.mean()*100]
lg_w=[hpb.total_runs.sum()/hpb.legal.sum()*6,((hpb.wkt==1)&(~hpb.nonbowl_wkt)).sum()/hpb.legal.sum()*100,((hpb.total_runs==0)&(hpb.legal==1)).sum()/hpb.legal.sum()*100]
def ipl_share(role,pid):
    dd=hp if role=='bat' else hpb; x=dd[dd.pid==pid]; return x.is_ipl.mean()*100
tb=[['#','Batter','HP balls','HP inns','WPOA/100b','Δ vs own','Consist.','SR (HP)','Bdry%','Dism/100','P(top10)','IPL %']]
for i,(pid,r) in enumerate(top_b.iterrows(),1):
    e=evid_bat(pid); tb.append([i,r.pname,int(r.n),int(r.ninn),f'{r.level:.2f}',f'{r.delta:+.2f}',f'{r.cons:.2f}',e[0],e[1],e[2],f'{r.p_top10:.2f}',f'{ipl_share("bat",pid):.0f}'])
tb.append(['','League avg HP','','','0','','',f'{lg_b[0]:.0f}',f'{lg_b[1]:.0f}',f'{lg_b[2]:.1f}','',''])
tw=[['#','Bowler','HP balls','HP inns','WPOA/100b','Δ vs own','Consist.','Econ (HP)','Wkt/100b','Dot %','P(top10)','IPL %']]
for i,(pid,r) in enumerate(top_w.iterrows(),1):
    e=evid_bowl(pid); tw.append([i,r.pname,int(r.n),int(r.ninn),f'{r.level:.2f}',f'{r.delta:+.2f}',f'{r.cons:.2f}',e[0],e[1],e[2],f'{r.p_top10:.2f}',f'{ipl_share("bowl",pid):.0f}'])
tw.append(['','League avg HP','','','0','','',f'{lg_w[0]:.2f}',f'{lg_w[1]:.1f}',f'{lg_w[2]:.0f}','',''])
pd.to_pickle(dict(pv=pv_rows,tb=tb,tw=tw,k_bat=est_k(build('bat'))[0],k_bowl=est_k(db)[0],n_el_b=len(fb),n_el_w=len(fw)),'rep.pkl')
print(pv_rows); print(tb); print(tw)
print(b.match_id.nunique(), len(b), b.is_ipl.groupby(b.match_id).first().sum())
