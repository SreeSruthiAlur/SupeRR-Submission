import pandas as pd, numpy as np, warnings; warnings.filterwarnings('ignore')
from rate import build, b
from score import table, est_k, W
from scipy.stats import spearmanr
rng=np.random.default_rng(7)
mdate=b.groupby('match_id').match_date.first().sort_values(); order=mdate.index.values
out={}
for role in ('bat','bowl'):
    d=build(role); k0=est_k(d)[0]; Ebase=table(d,k0); elig=Ebase.index
    d=d[d.pid.isin(elig)]
    agg=d.groupby(['pid','match_id','innings','HP']).v.agg(['size','sum']).reset_index()
    hp=agg[agg.HP].rename(columns={'size':'hn','sum':'hs'}).drop(columns='HP')
    lp=agg[~agg.HP].rename(columns={'size':'ln','sum':'ls'}).drop(columns='HP')
    A=hp.merge(lp,on=['pid','match_id','innings'],how='outer').fillna(0)
    A['c3']=(A.hn>=3).astype(int); A['pos']=((A.hn>=3)&(A.hs>0)).astype(int)
    p0=A[A.c3==1].pos.mean()
    def score_w(wt,Aw):
        X=Aw.assign(n=Aw.hn*wt,sv=Aw.hs*wt,nl=Aw.ln*wt,sl=Aw.ls*wt,ninn=Aw.c3*wt,npos=Aw.pos*wt).groupby('pid')[['n','sv','nl','sl','ninn','npos']].sum()
        X=X.reindex(elig).fillna(0)
        lvl=X.sv/(X.n+k0)*100; lpl=X.sl/(X.nl+k0)*100
        dl=lvl-lpl; cs=(X.npos+5*p0)/(X.ninn+5)
        z=lambda s:(s-s.mean())/s.std()
        return W[0]*z(lvl)+W[1]*z(dl)+W[2]*z(cs), lvl
    # full-sample check
    s_full,_=score_w(np.ones(len(A)),A)
    mids=A.match_id.unique(); R=[];S=[]
    for _ in range(300):
        cnt=pd.Series(rng.multinomial(len(mids),np.ones(len(mids))/len(mids)),index=mids)
        wt=A.match_id.map(cnt).values
        s,_=score_w(wt,A); S.append(s); R.append(s.rank(ascending=False))
    R=pd.concat(R,axis=1); S=pd.concat(S,axis=1)
    bs=pd.DataFrame({'pname':Ebase.pname,'score':Ebase.score,'boot_med_rank':R.median(1),'p_top10':(R<=10).mean(1),'p_top20':(R<=20).mean(1),'s_lo':S.quantile(.05,axis=1),'s_hi':S.quantile(.95,axis=1)})
    bs.to_pickle(f'boot_{role}.pkl')
    # split half
    half=pd.Series(np.arange(len(order))%2,index=order); A['h']=A.match_id.map(half)
    sc={}
    for h in (0,1):
        Ah=A[A.h==h]; Xh=Ah.assign(n=Ah.hn,sv=Ah.hs).groupby('pid')[['n','sv']].sum().reindex(elig).fillna(0)
        sc[h]=(Xh.sv/(Xh.n+k0)*100, Xh.sv/Xh.n.clip(lower=1)*100, Xh.n)
    ok=(sc[0][2]>=30)&(sc[1][2]>=30)
    r_sh=spearmanr(sc[0][0][ok],sc[1][0][ok])[0]; r_raw=spearmanr(sc[0][1][ok],sc[1][1][ok])[0]
    # Spearman-Brown corrected
    sb=2*r_raw/(1+r_raw) if r_raw>0 else np.nan
    out[role]=dict(split_half_raw=r_raw,split_half_shrunk=r_sh,spearman_brown=sb,n_pairs=int(ok.sum()),k=k0,p0=p0)
    print(role,out[role]); print(bs.sort_values('score',ascending=False).head(14).round(3).to_string())
pd.to_pickle(out,'reliab.pkl')
