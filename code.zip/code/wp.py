import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score, log_loss
b=pd.read_pickle('b.pkl')
# outcome class
def cls(r):
    pass
et=b.extras_type.values
legal=b.legal.values; wk=b.wkt.values; tr=b.total_runs.values
c=np.where(legal==0,'X',np.where(wk==1,'W',np.select([tr==0,tr==1,tr==2,tr==3,tr==4,tr==5,tr>=6],['0','1','2','3','4','4','6'],'6')))
b['cls']=c
b['phase']=np.select([b.overid<=6,b.overid<=15],[0,1],2)
OUT=['0','1','2','3','4','6','W','X']
dist=b.groupby(['innings','phase']).cls.value_counts(normalize=True).unstack().reindex(columns=OUT).fillna(0)
print(dist.round(3))
inn=b.innings.values
par=b[b.innings==1].groupby('balls_b').score_b.mean().reindex(range(0,140)).ffill().values
def F(innv,score,wkv,balls,target):
    bl=120-balls
    if innv==1:
        return np.c_[bl,wkv,score,score-par[np.clip(balls,0,139).astype(int)]]
    rn=target-score; rrr=np.where(bl>0,rn/np.maximum(bl,1)*6,60); rrr=np.clip(rrr,-5,60)
    return np.c_[bl,wkv,rn,rrr,target]
def after(sc,wkv,bl_,cl):
    # returns score, wk, balls after
    r={'0':0,'1':1,'2':2,'3':3,'4':4,'6':6,'W':0,'X':1}[cl]
    return sc+r, wkv+(cl=='W'), bl_+(0 if cl=='X' else 1)
b['wp_before']=np.nan; b['wp_after']=np.nan; b['ewp_after']=np.nan; b['lev']=np.nan; b['wp_alt']=np.nan
gkf=GroupKFold(n_splits=5)
oof_true=[];oof_p=[]
nonbowl=b.dismissal_type.isin(['RunOut','Obstracting the field','Obstructing the field','Retire Out']).values&(wk==1)
nonstr=(b.is_wicket.values)&(b.dismissed_player_id.values!=b.striker_id.values)
for iv in (1,2):
    idx=np.where(inn==iv)[0]; d=b.iloc[idx]
    sc=d.score_b.values; w=d.wk_b.values; ba=d.balls_b.values; tg=d.target.values.astype(float)
    y=d.bat_win.values; grp=d.match_id.values
    cl_=d.cls.values; ph=d.phase.values
    X=F(iv,sc,w,ba,tg)
    pb=np.zeros(len(d)); pa=np.zeros(len(d)); ep=np.zeros(len(d)); lv=np.zeros(len(d)); palt=np.zeros(len(d))
    for tr_i,te_i in gkf.split(X,y,grp):
        mdl=HGB(max_iter=200,learning_rate=0.05,max_depth=4,min_samples_leaf=500,l2_regularization=10.0,monotonic_cst=([0,-1,1,1] if iv==1 else [1,-1,-1,-1,0]),random_state=0).fit(X[tr_i],y[tr_i])
        pb[te_i]=mdl.predict_proba(X[te_i])[:,1]
        def P(s,ww,bb,mask=te_i):
            Xs=F(iv,s[mask],ww[mask],bb[mask],tg[mask]); p=mdl.predict_proba(Xs)[:,1]
            if iv==2:
                rn=tg[mask]-s[mask]; bl=120-bb[mask]
                p=np.where(rn<=0,1.0,np.where((ww[mask]>=10)|(bl<=0),0.0,p))
            return p
        # actual after
        ra=np.array([after(sc[i],w[i],ba[i],cl_[i]) for i in te_i]) if False else None
        # vectorised actual after
        s2=sc+d.total_runs.values; w2=w+d.wkt.values; b2=ba+d.legal.values
        pa[te_i]=P(s2,w2,b2)
        # no-wicket alt
        w3=w+0*d.wkt.values; palt[te_i]=P(s2,w3,b2)
        e=np.zeros(len(te_i)); outs=[]
        for k,cl in enumerate(OUT):
            r={'0':0,'1':1,'2':2,'3':3,'4':4,'6':6,'W':0,'X':1}[cl]
            s_=sc+r; w_=w+(1 if cl=='W' else 0); b_=ba+(0 if cl=='X' else 1)
            outs.append(P(s_,w_,b_))
        outs=np.array(outs).T  # n x 8
        pr=dist.loc[[(iv,p) for p in ph[te_i]]].values
        ep[te_i]=(outs*pr).sum(1)
        lv[te_i]=(np.abs(outs-pb[te_i][:,None])*pr).sum(1)
    b.loc[b.index[idx],['wp_before','wp_after','ewp_after','lev','wp_alt']]=np.c_[pb,pa,ep,lv,palt]
    print('inn',iv,'OOF AUC',round(roc_auc_score(y,pb),3),'logloss',round(log_loss(y,np.clip(pb,1e-4,1-1e-4)),3),'base',round(log_loss(y,np.full(len(y),y.mean())),3))
b['d_wp']=b.wp_after-b.wp_before
b['wpoa']=b.wp_after-b.ewp_after   # batting-side value over average ball
b['wpoa_alt']=b.wp_alt-b.ewp_after
b['nonbowl_wkt']=nonbowl; b['nonstr_wkt']=nonstr
b.to_pickle('b2.pkl')
print(b[['lev','wpoa']].describe())
print(b.groupby('innings').lev.quantile([.5,.75,.9]))
