import pandas as pd, numpy as np
from rate import build, b, THR
MIN_BALLS={'bat':120,'bowl':120}; MIN_INN=12
W=(0.60,0.15,0.25)
def est_k(d):
    hp=d[d.HP]; s2=hp.v.var()
    g=hp.groupby('pid').v.agg(['mean','size']); g=g[g['size']>=50]
    tau2=max(g['mean'].var()-(s2/g['size']).mean(),1e-9)
    return s2/tau2, s2, tau2
def table(d,k=None,w=W,minb=150,mininn=15,p0=None,elig=None):
    if k is None: k=est_k(d)[0]
    hp=d[d.HP]; lp=d[~d.HP]
    A=hp.groupby('pid').agg(pname=('pname','last'),n=('v','size'),sv=('v','sum'))
    L=lp.groupby('pid').agg(nl=('v','size'),sl=('v','sum'))
    mi=hp.groupby(['pid','match_id','innings']).v.agg(['sum','size']).reset_index(); mi=mi[mi['size']>=3]
    mi['pos']=(mi['sum']>0).astype(int)
    C=mi.groupby('pid').agg(ninn=('pos','size'),npos=('pos','sum'))
    T=A.join(L).join(C).fillna({'nl':0,'sl':0,'ninn':0,'npos':0})
    if p0 is None: p0=mi.pos.mean()
    T['level']=T.sv/(T.n+k)*100
    T['lp_lvl']=T.sl/(T.nl+k)*100
    T['delta']=T.level-T.lp_lvl
    T['cons']=(T.npos+5*p0)/(T.ninn+5)
    E=(T[(T.n>=minb)&(T.ninn>=mininn)] if elig is None else T.loc[T.index.intersection(elig)]).copy()
    z=lambda s:(s-s.mean())/s.std()
    E['score']=w[0]*z(E.level)+w[1]*z(E.delta)+w[2]*z(E.cons)
    return E.sort_values('score',ascending=False)
if __name__=='__main__':
    for role in ('bat','bowl'):
        d=build(role); k,s2,t2=est_k(d)
        print(role,'k=',round(k,1),'sigma2',round(s2,5),'tau2',round(t2,7))
        E=table(d,k); print(len(E),'eligible')
        print(E.head(15)[['pname','n','ninn','level','delta','cons','score']].round(3).to_string())
        E.to_pickle(f'E_{role}.pkl')
