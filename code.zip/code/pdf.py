import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
R=pd.read_pickle('rep.pkl')
ss=getSampleStyleSheet()
H1=ParagraphStyle('h1',parent=ss['Heading1'],fontSize=15,spaceAfter=6,textColor=colors.HexColor('#1f3a5f'))
H2=ParagraphStyle('h2',parent=ss['Heading2'],fontSize=11.5,spaceBefore=9,spaceAfter=4,textColor=colors.HexColor('#1f3a5f'))
B=ParagraphStyle('b',parent=ss['BodyText'],fontSize=9,leading=12.3,spaceAfter=4)
BL=ParagraphStyle('bl',parent=B,leftIndent=12,bulletIndent=2,spaceAfter=2)
SM=ParagraphStyle('sm',parent=B,fontSize=7.5,leading=9.5,textColor=colors.HexColor('#444444'))
def P(t): return Paragraph(t,B)
def BU(t): return Paragraph(t,BL,bulletText='•')
def tbl(data,cw=None,fs=7,hl=None):
    t=Table(data,colWidths=cw,repeatRows=1)
    st=[('FONTSIZE',(0,0),(-1,-1),fs),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#1f3a5f')),('TEXTCOLOR',(0,0),(-1,0),colors.white),
        ('GRID',(0,0),(-1,-1),.25,colors.HexColor('#bbbbbb')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f3f6fa')]),
        ('ALIGN',(2,0),(-1,-1),'CENTER'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]
    t.setStyle(TableStyle(st)); return t
S=[]
S.append(Paragraph('SupeRR Selector S2 - Round 1: Who Delivers Under Pressure?',H1))
S.append(Paragraph('<b>Methodology report</b> - win-probability leverage, state-neutral performance (WPOA), shrinkage and consensus ranking',B))
S.append(Paragraph('1. Summary',H2))
S.append(P('We define pressure as <b>leverage</b>: how much the next ball can swing the batting side\'s win probability, given the exact match state (score, wickets, balls left, target). Every delivery is then scored by <b>win probability added over an average ball in the same state (WPOA)</b>, so a player is only credited for what they did <i>beyond</i> what an average player would have done in that identical situation. Ratings use only high-pressure balls, are shrunk toward the league mean to control sample-size luck, are combined with a "vs own normal" delta and a consistency measure, and the final order is a <b>consensus of three independent views</b> (base model, 54-scenario sensitivity grid, 300-resample bootstrap).'))
fb=pd.read_pickle('final_bat.pkl').head(10); fw=pd.read_pickle('final_bowl.pkl').head(10)
rk=[['Rank','Top-10 batters','Top-10 bowlers']]+[[i+1,fb.pname.iloc[i],fw.pname.iloc[i]] for i in range(10)]
S.append(tbl(rk,[1.5*cm,6*cm,6*cm],fs=8.5))
S.append(Paragraph('2. Data and cleaning',H2))
S.append(P('Ball-by-ball data covers 867 matches (IPL 2022-26 and T20Is). We keep <b>814 valid matches / 194,416 deliveries</b> (356 IPL, 458 T20I): matches with no result, abandoned or tied are dropped (no outcome label); DLS-affected games (revised target or overs) and shortened first innings are dropped (state arithmetic is not comparable); super overs are excluded. Total runs per ball = bat runs + extras1 + extras2. A delivery is legal unless it is a wide, overstep (no-ball) or "other" extra. Wickets exclude "Retire Out". Match state before each ball (score, wickets, legal balls bowled) is rebuilt by cumulative sums; the chase target = first-innings total + 1.'))
S.append(Paragraph('3. Defining pressure',H2))
S.append(P('<b>Win-probability model.</b> One gradient-boosted model per innings (monotonic constraints: more wickets lost or runs needed can only lower win probability). Chase features: balls left, wickets lost, runs needed, required rate, target. First-innings features: balls left, wickets, score, score minus league-par score at that ball. All probabilities are <b>out-of-fold</b> (5-fold, grouped by match) so a match never predicts itself. Out-of-fold AUC = <b>0.883</b> (chase) and 0.679 (setting a total, where no target exists); log-loss 0.425 vs 0.692 baseline (chase). We early-tested a current-run-rate feature and removed it because it created spurious early-over "pressure" from tiny samples.'))
S.append(P('<b>Leverage.</b> For each ball we evaluate the win probability after each possible outcome o in {0,1,2,3,4,6,W,extra}, weighted by the league probability p(o | innings, phase): <b>L = sum_o p(o) x |WP(state after o) - WP(state before)|</b>. This is a single score that automatically blends required rate, wickets in hand, balls left, innings stage and closeness. <b>High pressure (HP) = leverage in the top 25% of all balls (L >= 0.0192).</b> This is not just "death overs": 27% of powerplay, 22% of middle and 29% of death balls qualify; in chases, HP balls have an average required rate of 10.2 vs 12.0 for ordinary balls because hopeless chases (and cruising ones) have <i>low</i> leverage - the game must be in the balance.'))
S.append(Image('f1.png',width=16.5*cm,height=5.8*cm))
S.append(tbl(R['pv'],[3.6*cm,1.8*cm,1.8*cm,1.4*cm,2*cm,1.9*cm,1.7*cm,1.7*cm],fs=7.5))
S.append(Paragraph('Table 1. High-pressure balls are far more decisive: in chases, 43% are in close games (vs 11%) and the real average win-probability swing is 5x larger (3.85% vs 0.70% per ball). Scoring rates are similar by construction - pressure is about stakes, not tempo.',SM))
S.append(Paragraph('4. Measuring performance',H2))
S.append(P('<b>WPOA (state-neutral value of every ball).</b> WPOA = WP(actual next state) - E[WP(next state)] where the expectation uses league outcome frequencies for that innings and phase. A dot ball when 14 an over is needed scores near zero if an average ball would also have helped little - it is relative to the situation, which is why no separate "phase" or "required-rate" baseline is needed. Batters are credited on legal balls without leg-byes/byes; bowlers are charged for every ball (wides, no-balls, byes). Run-outs are removed from the bowler, and non-striker run-outs from the striker, by re-evaluating the state without the wicket.'))
S.append(P('<b>Opposition adjustment.</b> A Bradley-Terry team rating (ridge logistic regression on match results) is standardised <i>separately</i> inside the IPL pool and the T20I pool (the two pools never meet, so ratings are not comparable across them). Positive value against stronger opposition is scaled up by up to +30% (and negative value scaled down), the reverse for weaker opposition: w = clip(1 + 0.12 z, 0.7, 1.3).'))
S.append(P('<b>Own baseline.</b> Each player\'s HP level is compared with their own level on non-pressure balls (delta = HP level - normal level, both shrunk), which directly answers "compared with their usual performance".'))
S.append(Paragraph('5. Rating construction and fair comparison',H2))
S.append(BU('<b>Eligibility:</b> at least 150 pressure balls and 15 pressure innings (>=3 pressure balls in the innings) - %d batters and %d bowlers qualify.'%(R['n_el_b'],R['n_el_w'])))
S.append(BU('<b>Shrinkage (empirical Bayes):</b> level = sum(WPOA) / (n + k) x 100 per 100 balls. k = noise variance / true-talent variance is estimated from the data (<b>k = %.0f</b> batters, <b>%.0f</b> bowlers pressure balls), pulling thin samples toward average (Figure 4).'%(R['k_bat'],R['k_bowl'])))
S.append(BU('<b>Consistency:</b> share of pressure innings with positive net WPOA (shrunk with 5 pseudo-innings at the league rate of about 55%/50%) - rewards reliable rather than one-off impact, as the brief asks.'))
S.append(BU('<b>Composite score</b> = 0.60 z(level) + 0.15 z(delta vs own normal) + 0.25 z(consistency), z-scored within the eligible pool, separately for batting and bowling.'))
S.append(BU('<b>IPL + T20I:</b> both are pooled so the sample is large, the pressure scale (win probability) is common to both, opposition strength is standardised within each pool, and the IPL share of each top player\'s pressure balls is disclosed in Tables 2-3. T20I specialists from smaller sides are the most exposed to residual opposition-quality bias (see limitations).'))
S.append(Image('f4.png',width=8.5*cm,height=5.9*cm))
S.append(Paragraph('6. Evidence for the top 10',H2))
S.append(P('WPOA/100b = shrunk win-probability added over average per 100 pressure balls (percentage points). Delta = vs own normal. Consist. = share of positive pressure innings. P(top10) = bootstrap probability.'))
S.append(tbl(R['tb'],[.6*cm,3.3*cm,1.2*cm,1.1*cm,1.4*cm,1.2*cm,1.2*cm,1.2*cm,1*cm,1.2*cm,1.3*cm,1*cm],fs=6.5))
S.append(Paragraph('Table 2. Batters. SR/Bdry%/Dism are raw pressure-ball figures; the league averages are 143 SR, 19% boundaries, 5.9 dismissals per 100 balls.',SM))
S.append(Image('f2.png',width=11.5*cm,height=5.9*cm))
S.append(tbl(R['tw'],[.6*cm,3.3*cm,1.2*cm,1.1*cm,1.4*cm,1.2*cm,1.2*cm,1.2*cm,1.2*cm,1*cm,1.3*cm,1*cm],fs=6.5))
S.append(Paragraph('Table 3. Bowlers. League pressure averages: economy 8.94, 5.4 wickets per 100 balls, 35% dots (run-outs not credited to bowlers).',SM))
S.append(Image('f3.png',width=11.5*cm,height=5.9*cm))
S.append(P('<b>Reading the lists.</b> Batters at the top combine high strike rate with low dismissal rate on high-leverage balls (e.g. Salt: 170 SR at 2.5 dismissals per 100 balls; Sooryavanshi: 243 SR with 43% boundaries). Bowlers typically win on dot-ball pressure plus wickets: Taskin Ahmed takes 9.0 wickets per 100 pressure balls against a 5.4 average; Narine and Mujeeb concede 6.3 and 6.0 an over against 8.9.'))
S.append(Paragraph('7. Reliability and limitations',H2))
rb=pd.read_pickle('reliab.pkl')
S.append(BU('<b>Split-half (odd vs even matches):</b> pressure-skill correlation = %.2f (batters) and %.2f (bowlers) raw; %.2f / %.2f Spearman-Brown corrected. Pressure performance is inherently noisy, which is why shrinkage, a consistency term and consensus ranking are used rather than trusting one point estimate.'%(rb['bat']['split_half_raw'],rb['bowl']['split_half_raw'],rb['bat']['spearman_brown'],rb['bowl']['spearman_brown'])))
S.append(BU('<b>Bootstrap (300 resamples of matches):</b> the 90% intervals in Figures 2-3 overlap for positions 4-12, so ranks inside that band are close calls; the top 3 batters (David, Sooryavanshi, Maxwell) and top 4 bowlers (Ferguson, Taskin, Raza, Shoriful) are the most stable.'))
S.append(BU('<b>Sensitivity grid (54 scenarios):</b> HP cut-off (top 30/25/20%), composite weights (3 sets, incl. level-only), opposition adjustment on/off, shrinkage x0.5/x1/x2. Every listed player appears in the top 20 of nearly all scenarios.'))
S.append(BU('<b>Consensus rank</b> = average of base-model rank, grid mean rank and bootstrap median rank; the submission uses this order.'))
S.append(BU('<b>Limitations:</b> (i) no pitch, venue or fielding data; (ii) first-innings win probability is weaker (AUC 0.68) so first-innings pressure is less precisely located; (iii) smaller T20I teams may still inflate some players despite the opposition adjustment; (iv) the win-probability model is team-level and does not know who is batting (a tail-ender facing a hard over gets the same leverage); (v) 150 pressure balls is still a modest sample - all ranks carry real uncertainty; (vi) the supplied data is a subset of all T20Is since 2022.'))
S.append(Paragraph('8. Reproducibility',H2))
S.append(P('Pipeline (Python 3, pandas, scikit-learn): prep.py (clean + state) -> wp.py (out-of-fold win probability, leverage, WPOA) -> rate.py (opposition ratings, ball values) -> score.py (shrinkage, composite) -> robust.py (54-scenario grid) -> boot.py (bootstrap, split-half) -> consensus ranking. Key parameters: HGB depth 4, 200 iterations, min leaf 500, L2 = 10; HP = pooled 75th percentile of leverage; opposition weight 0.12 clipped to [0.7, 1.3]; composite weights 0.60/0.15/0.25; eligibility 150 balls and 15 innings; random seed 0 (model) and 7 (bootstrap).'))
SimpleDocTemplate('/mnt/user-data/outputs/Methodology_Report_Pressure_Players.pdf',pagesize=A4,leftMargin=1.6*cm,rightMargin=1.6*cm,topMargin=1.5*cm,bottomMargin=1.5*cm,title='SupeRR Selector S2 Round 1 Methodology').build(S)
